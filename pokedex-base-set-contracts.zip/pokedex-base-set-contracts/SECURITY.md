# Security Policy

## Security posture

This is an **unaudited, testnet-only** repository. It is not a mainnet deployment package and does not represent an investment product, custody system, token sale, or promise of value. The controls in this repository reduce operational ambiguity; they do not replace independent review, deployment controls, or a formal audit.

## Reporting a vulnerability

Please **do not open a public issue, pull request, discussion, or social-media post** for a suspected vulnerability. Use the canonical GitHub repository's private vulnerability-reporting feature when it is available. If private reporting is not enabled, contact the maintainers through the verified contact path published at [Pokedex Markets](https://pokedexmarkets.xyz) and state that the message is a security report.

A useful report identifies the affected contract and commit, the network or local reproduction setup, the impact, concise reproduction steps or a proof of concept, and any suggested mitigation. Please avoid publishing exploitable details until maintainers have had a reasonable opportunity to assess and address the report.

| Report stage | Expected handling                                                                                    |
| ------------ | ---------------------------------------------------------------------------------------------------- |
| Receipt      | Acknowledge the report as soon as practical and establish a private discussion path.                 |
| Triage       | Assess reproducibility, affected deployment scope, impact, and temporary mitigation options.         |
| Remediation  | Prepare a tested fix, documentation updates, and any needed deployment or role-rotation plan.        |
| Disclosure   | Coordinate timing with the reporter when practical, then publish a factual advisory or release note. |

## In scope

The following areas are in scope for responsible disclosure:

- Access-control, pause, treasury-withdrawal, and contribution-accounting behavior in `BaseSetTestnetLiquidityPool`.
- Oracle authorization, duplicate protection, evidence-record immutability, and metadata validation in `BaseSetPriceEvidenceRegistry`.
- Operator authorization, lifecycle transitions, and module binding in `PokedexMarketRegistry`.
- Deployment scripts, ABI exports, and documentation when they could cause a materially unsafe or misleading integration.

## Out of scope

The following are generally out of scope unless they directly expose a repository-maintained secret or cause contract behavior contrary to the documented interface:

- Testnet token value or faucet availability.
- Third-party wallet, RPC, browser-extension, hosting, or price-provider outages.
- Social engineering, phishing, or issues requiring access to a user account or private key.
- The economic merit, price movement, or completeness of off-chain card pricing.

## Deployment expectations

Do not deploy these contracts to mainnet. Before any public testnet deployment, complete the checklist in [docs/SECURITY.md](docs/SECURITY.md), validate the environment with `pnpm check:env`, run `pnpm validate`, confirm intended role addresses independently, and retain deployment transaction hashes in an operational record.
