# Security

> **No audit has been performed.** These contracts are intentionally scoped to a testnet proof and must not be presented as audited, production-ready, or suitable for holding real-value assets.

## Security posture

The repository aims to make the testnet proof reviewable, not to imply mainnet readiness. It uses conservative controls—role separation, a per-transaction receipt cap, pause capability, reentrancy protection, and hash-addressed evidence—while acknowledging that these do not replace an independent security review.

| Property              | Current approach                                                 | Remaining limitation                                                                    |
| --------------------- | ---------------------------------------------------------------- | --------------------------------------------------------------------------------------- |
| Contribution receipts | Canonical event plus per-address accounting.                     | The pool accepts native testnet funds and a privileged role can withdraw after pausing. |
| Contribution limit    | Immutable per-transaction cap established at deployment.         | A cap does not eliminate operational or key-management risk.                            |
| Pausing               | Stops new receipts and new evidence records.                     | Pausing does not reverse confirmed transactions.                                        |
| Treasury movement     | Pool must be paused; treasury role performs explicit withdrawal. | Role compromise remains a risk.                                                         |
| Evidence records      | Immutable snapshot IDs, source hashes, and component hashes.     | On-chain code cannot verify the truth of an external pricing API response.              |
| Upgradeability        | None. Contracts are immutable after deployment.                  | A future change requires a new, separately disclosed deployment.                        |

## Non-goals

This package does **not** implement any of the following:

- A token, NFT, derivative, share, redemption, or yield mechanism.
- Mainnet deployment logic or production custody.
- Automated market making, swaps, borrowing, liquidation, or price prediction.
- On-chain TCG pricing computation or an assertion that any price source is authoritative.
- Private-key management, multisig implementation, monitoring service, or incident-response runbook outside the supplied documentation.

## Threat model highlights

| Threat                                    | Mitigation in this repository                          | Operator responsibility                                                               |
| ----------------------------------------- | ------------------------------------------------------ | ------------------------------------------------------------------------------------- |
| Accidental oversized testnet contribution | Deployment-time immutable cap.                         | Keep the cap conservative and disclose it in the UI.                                  |
| Unauthorized contribution halt            | Restricted `PAUSER_ROLE`.                              | Use a protected, observable role holder and document role assignments.                |
| Treasury key compromise                   | Withdrawal requires a separate role and a paused pool. | Use a testnet multisig or hardware-backed signer; rotate roles when needed.           |
| Incorrect API data                        | Evidence digest binds a documented off-chain bundle.   | Validate component/variant selection and state coverage limitations in the public UI. |
| Replay of an evidence submission          | Unique `snapshotId` is recorded once.                  | Construct deterministic IDs and retain the full evidence bundle off-chain.            |
| Reentrancy at withdrawal                  | `nonReentrant` guard and checks before external call.  | Verify the deployed bytecode and role configuration.                                  |

## Pre-deployment checklist

Before testnet deployment, complete every item below.

1. Compile and test a clean clone with `pnpm validate`.
2. Review the generated ABI and confirm the app needs only the documented `contribute()` function and receipt event.
3. Set a funded **testnet-only** deployer key; never place a mainnet key in `.env`.
4. Use distinct `ADMIN_ADDRESS`, `TREASURY_ADDRESS`, and `ORACLE_ADDRESS` values where operationally possible.
5. Check that `BASE_SET_MAX_CONTRIBUTION_ETH` is a conservative testnet limit.
6. Publish contract addresses, role holders, deployment block numbers, and source-code commit hash.
7. Confirm that the application labels the deployment as unaudited and testnet-only.
8. Save the deployment manifest and exported ABI with the release tag.

## Vulnerability reporting

Do not open a public issue with a suspected vulnerability. Report it privately to the project maintainer through the contact method listed in the GitHub repository settings. Include a minimal proof of concept, affected commit hash, impact, and suggested mitigation when possible.

The project should acknowledge credible reports, investigate privately, and publish a coordinated remediation note once users are safe to inform.
