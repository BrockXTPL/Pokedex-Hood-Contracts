// SPDX-License-Identifier: MIT
pragma solidity 0.8.24;

import {AccessControl} from "@openzeppelin/contracts/access/AccessControl.sol";
import {Pausable} from "@openzeppelin/contracts/utils/Pausable.sol";
import {ReentrancyGuard} from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
import {IContributionReceiver} from "./interfaces/IContributionReceiver.sol";

/// @title BaseSetTestnetLiquidityPool
/// @notice A deliberately limited, testnet-only native-token contribution receiver for the Pokedex Base Set proof.
/// @dev This contract is not an investment product, does not issue assets, and is not designed for mainnet use.
contract BaseSetTestnetLiquidityPool is
    IContributionReceiver,
    AccessControl,
    Pausable,
    ReentrancyGuard
{
    bytes32 public constant PAUSER_ROLE = keccak256("PAUSER_ROLE");
    bytes32 public constant TREASURY_ROLE = keccak256("TREASURY_ROLE");

    string public constant MARKET_KEY = "BASE_SET_HOLOFOIL_V1";
    string public constant VERSION = "1.0.0-testnet";

    address payable public treasury;
    uint256 public immutable maxContributionWei;
    uint256 public totalContributed;
    uint256 public contributionCount;

    mapping(address contributor => uint256 amount) public contributionOf;
    mapping(address contributor => uint256 count) public contributionCountOf;

    event TreasuryUpdated(
        address indexed previousTreasury,
        address indexed nextTreasury,
        address indexed actor
    );
    event PoolPaused(address indexed actor);
    event PoolUnpaused(address indexed actor);
    event TreasuryWithdrawal(address indexed treasury, uint256 amount, address indexed actor);

    error ZeroAddress();
    error ZeroContribution();
    error ContributionTooLarge(uint256 submitted, uint256 maximum);
    error WithdrawalFailed();
    error UnsupportedCall();

    /// @param admin Multisig or administrative account that owns operational roles.
    /// @param initialTreasury Testnet address permitted to receive funds after the pool is paused.
    /// @param contributionCapWei Maximum native-token amount accepted per contribution transaction.
    constructor(address admin, address payable initialTreasury, uint256 contributionCapWei) {
        if (admin == address(0) || initialTreasury == address(0)) revert ZeroAddress();
        if (contributionCapWei == 0) revert ZeroContribution();

        treasury = initialTreasury;
        maxContributionWei = contributionCapWei;

        _grantRole(DEFAULT_ADMIN_ROLE, admin);
        _grantRole(PAUSER_ROLE, admin);
        _grantRole(TREASURY_ROLE, admin);
    }

    /// @notice Contribute testnet native tokens using the app-compatible ABI.
    function contribute() external payable override whenNotPaused nonReentrant {
        _acceptContribution(msg.sender, msg.value);
    }

    /// @notice Direct native-token transfers are accepted and recorded using the same receipt event.
    receive() external payable whenNotPaused nonReentrant {
        _acceptContribution(msg.sender, msg.value);
    }

    /// @dev Rejects unknown function calls instead of silently accepting calldata and funds.
    fallback() external payable {
        revert UnsupportedCall();
    }

    /// @notice Temporarily halts new contributions. Existing balances are unaffected.
    function pause() external onlyRole(PAUSER_ROLE) {
        _pause();
        emit PoolPaused(msg.sender);
    }

    /// @notice Resumes contribution collection after a tested operational decision.
    function unpause() external onlyRole(PAUSER_ROLE) {
        _unpause();
        emit PoolUnpaused(msg.sender);
    }

    /// @notice Updates the testnet treasury recipient. Does not move funds.
    function setTreasury(address payable nextTreasury) external onlyRole(DEFAULT_ADMIN_ROLE) {
        if (nextTreasury == address(0)) revert ZeroAddress();
        address previousTreasury = treasury;
        treasury = nextTreasury;
        emit TreasuryUpdated(previousTreasury, nextTreasury, msg.sender);
    }

    /// @notice Moves accepted balance to the configured treasury only while contributions are paused.
    /// @dev Pausing before withdrawal provides an observable operational boundary for testnet reconciliation.
    function withdrawToTreasury(
        uint256 amount
    ) external onlyRole(TREASURY_ROLE) whenPaused nonReentrant {
        if (amount == 0) revert ZeroContribution();
        (bool succeeded, ) = treasury.call{value: amount}("");
        if (!succeeded) revert WithdrawalFailed();
        emit TreasuryWithdrawal(treasury, amount, msg.sender);
    }

    /// @notice Returns a compact public status view useful to indexers and client integrations.
    function contributionStatus()
        external
        view
        returns (
            string memory marketKey,
            string memory version,
            address currentTreasury,
            uint256 capWei,
            uint256 receivedWei,
            uint256 receivedCount,
            bool isPaused
        )
    {
        return (
            MARKET_KEY,
            VERSION,
            treasury,
            maxContributionWei,
            totalContributed,
            contributionCount,
            paused()
        );
    }

    function _acceptContribution(address contributor, uint256 amount) private {
        if (amount == 0) revert ZeroContribution();
        if (amount > maxContributionWei) revert ContributionTooLarge(amount, maxContributionWei);

        totalContributed += amount;
        contributionCount += 1;
        contributionOf[contributor] += amount;
        contributionCountOf[contributor] += 1;

        emit ContributionReceived(contributor, amount);
    }
}
